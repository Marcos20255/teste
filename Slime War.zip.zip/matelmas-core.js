class MatelmasCore {
  constructor({ nucleos = [], apps = [], contextBuilder = null }) {
    this.nucleos = nucleos;
    this.apps = apps;
    this.contextBuilder = contextBuilder;
    this.context = {};
  }

  async start() {
    try {
      // Carregar e inicializar núcleos
      for (const modulo of this.nucleos) {
        const moduloImportado = await this.loadModule(modulo);
        if (moduloImportado.start) {
          await moduloImportado.start(this.context);
        }
        this.context[modulo.name] = moduloImportado;
      }

      // Criar contexto
      if (this.contextBuilder) {
        const ContextBuilderClass = await this.loadModule(this.contextBuilder);
        this.contextBuilder = new ContextBuilderClass();
        await this.contextBuilder.init(this.context);
      }

      // Mostrar anúncio após iniciar tudo
      if (typeof gdsdk !== 'undefined' && gdsdk.showAd) {
        console.log("🔔 Exibindo anúncio inicial (teste)");
        gdsdk.showAd();
      } else {
        console.log("⚠️ GameMonetize SDK não está pronto ou não foi carregado");
      }

      // Carregar e iniciar apps
      for (const app of this.apps) {
        const AppClass = await this.loadModule(app);
        const instancia = new AppClass();
        if (instancia.init) {
          await instancia.init(this.context);
        }
      }

    } catch (erro) {
      console.error("Erro ao iniciar o núcleo:", erro);
    }
  }

  async loadModule(moduleConfig) {
    try {
      const modulo = await import(moduleConfig.path);
      if (!modulo.default) {
        throw new Error(`Módulo "${moduleConfig.name}" não tem exportação default`);
      }
      return new modulo.default();
    } catch (erro) {
      console.error(`Erro ao carregar módulo "${moduleConfig.name}":`, erro);
      throw erro;
    }
  }
}

export default MatelmasCore;
